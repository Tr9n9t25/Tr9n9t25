
let button = documnet.getElementById('mobilebtn');
button.addEventListener(click, toggle);


function toggle() {
    let one = document.getElementById('mobilehiden');
    one.classList.add('active');


}


let exit = document.getElementById('exitb');
exit.addEventListener(click, exit);

function exitmenu() {
    let one = document.getElementById('mobilehiden');
    one.classList.remove('active');


}