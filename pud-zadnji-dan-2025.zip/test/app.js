
const gumb = document.getElementById('gmb1')
gumb.addEventListener('click', funkcija);

function funkcija() {

    document.getElementById('page').classList.toggle('barva')
};