
/*
let array = lsread();


const section = document.getElementById('sec1')
const btn = document.getElementById('btn')
let html = ''
btn.addEventListener('click', pupper)
const selectiondog = document.getElementById('dog');
const selectioncat = document.getElementById('cat');

let lliked = document.getElementById('ll');


function printli() {
    for (let i in array) {
        let add = `<li><img src='${array[i]}'></li>`;
        lliked.innerHTML += add;

    }
}


async function pupper() {
    section.innerHTML = '';
    let url = await fetch(type())
    const res = await url.json();
    console.log(res)
    res.forEach(res => {
        const result = res.url;
        html = `<div><img class="feed-img" src="${result}"><button data-src='${result}' class="liked">Like</button></div>`;
        section.innerHTML += html;

    })
    const buttons = Array.from(document.getElementsByClassName('liked'));
    buttons.forEach(item => {

        item.addEventListener('click', function () {
            let link = item.getAttribute('data-src')
            console.log(link);

            toLiked(link)
            // printli()

        })


    })
}



function type() {
    if (selectiondog.checked === true) {
        return "https:\\api.thedogapi.com/v1/images/search?limit=5"
    }
    else if (selectioncat.checked === true) {
        return "https:\\api.thecatapi.com/v1/images/search?limit=5"
    }
    else {
        console.log("error")
    }
}


let i = 0;

function toLiked(url) {
    console.log(url, array);

    array.push(url)
    lswrite(array)
}


function lsread() {
    console.log(localStorage.getItem('img'));

    const data = JSON.parse(localStorage.getItem('img') || "[]")
    return [data];
}

function lswrite(arry) {
    console.log(JSON.stringify(arry));

    JSON.stringify(localStorage.setItem('img', arry))

}


let button = document.getElementsByClassName('splice');


*/



const likedArray = JSON.parse(localStorage.getItem('liked') || "[]")


async function pup() {
    section.innerHTML = '';
    let url = await fetch(type());
    const res = await url.json();

    res.forEach(res => {
        const result = res.url;
        html = `<div><img class="feed-img" src="${result}"><button data-src="${result}" class="liked">Like</button></div>`;
        section.innerHTML += html;

    })
    const buttons = Array.from(document.getElementsByClassName('liked'));
    buttons.forEach(item => {

        item.addEventListener('click', function () {
            let link = item.getAttribute('data-src')

            lswrite(link)


        })


    })
}


function type() {
    if (selectiondog.checked === true) {
        return "https:\\api.thedogapi.com/v1/images/search?limit=5"
    }
    else if (selectioncat.checked === true) {
        return "https:\\api.thecatapi.com/v1/images/search?limit=5"
    }
    else {
        console.log("error")
    }
}

function lswrite(url) {
    likedArray.push(url)
    const stringArr = JSON.stringify(likedArray)
    localStorage.setItem('liked', stringArr)

}


const selectiondog = document.getElementById('dog');
const selectioncat = document.getElementById('cat');
const section = document.getElementById('sec1')
const btn = document.getElementById('btn');
btn.addEventListener('click', pup);