
let like = document.getElementById('likedlistitem');

const array = read()
console.log(array)
function read() {
    const data = JSON.parse(localStorage.getItem('liked') || "[]")
    return data
}
printli()


function printli() {
    for (let i in array) {
        let add = `<div id="list"><li><img src='${array[i]}'><button class="delbtn">x</button></li></div>`;
        like.innerHTML += add;
        findli()
    }

}

function findli() {
    const likeditems = Array.from(document.querySelectorAll("#likedlistitem #list li button"))
    for (let item in likeditems) {
        likeditems[item].addEventListener('click', function () {
            array.splice(item, 1, '')
            xyz()

        })

    }
}


function xyz() {
    let dasdas = printli();
    like.innerHTML -= dasdas;
    printli()
}


