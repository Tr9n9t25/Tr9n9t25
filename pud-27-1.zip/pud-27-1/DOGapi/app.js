const section = document.getElementById('sec1')
const btn = document.getElementById('btn')
let html = ''
btn.addEventListener('click', pupper)

let selection = document.getElementById('dog');
let addhtml = [];

string()

function string() {
    addhtml = lsread()
    for (let l in addhtml) {
        let text = json.stringifyl(addhtml[l])
        toLiked(text || "")
    }
    lsread()

}




let like = document.getElementById('liked');
like.addEventListener('click', toLiked);
let lliked = document.getElementById('ll');

async function pupper() {
    section.innerHTML = '';
    let url = await fetch(type(selection))
    const res = await url.json();
    console.log(res)
    res.forEach(res => {
        const result = res.url;
        console.log(result)
        html = `<img id="img" src="${result}">`;
        section.innerHTML += html;
        lsread()

    })
}


function type(input) {
    if (input.checked === true) {
        return "https://api.thedogapi.com/v1/images/search"
    }
    else if (input.checked === false) {
        return "https://api.thecatapi.com/v1/images/search"
    }


}



function toLiked(x) {
    lliked.innerHTML += x;
    let link = document.getElementById('img').src;
    let add = `<li><img src='${link}'></li>`;
    lliked.innerHTML += add;
    lswrite(add)


}


function lsread() {

    const data = []
    for (let i in data) {

        data[i] = JSON.parse(localStorage.getItem(('img' + i) || ""))
        return data[i]
    }

}

function lswrite(add) {
    const dataString = [];
    for (let j in dataString) {
        dataString = add;
        localStorage.setItem('img', dataString)
    }
}