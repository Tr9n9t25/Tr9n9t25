let search = document.getElementById('sbar');
let button = document.getElementById('btn');
let section = document.getElementById('text');

async function fetchData(word) {
    const req = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
    const res = await req.json();
    section.innerHTML = '';

    res.forEach(item => {
        const meanings = item.meanings;
        let html = '';
        meanings.forEach(meaning => {
            console.log(meaning)
            html += `<h1>${meaning.partOfSpeech}</h1>`
            const definitions = meaning.definitions;
            html += `<ul>`
            definitions.forEach(definition => {
                console.log(definition)
                html += `<li>${definition.definition}</li>`
                html += `<li>Example: ${definition.example}</li><br>`
            })
            html += `</ul>`
        })
        section.innerHTML += html;
    })

}



button.addEventListener('click', data);
function data() {
    let values = search.value;
    fetchData(values);
}






