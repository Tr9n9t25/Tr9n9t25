
const listparent = document.getElementById('parent');
const element = document.getElementById('submit');
const input = document.getElementById('inputform')
// element.addEventListener('click', write);


const array = lsread();

function write() {
    let item = "";
    for (let i in array) {
        item += `<div class="list"><li>${array[i]}<button class="splice"> X</button ></li></div>`
    }
    listparent.innerHTML = item
    findli()
    lswrite()
}

write()

element.addEventListener('click', function () {
    const inputValue = input.value

    array.push(inputValue)
    write()
})

let button = document.getElementsByClassName('splice');

function findli() {
    const todoitems = Array.from(document.querySelectorAll("#parent li button"))

    for (let item in todoitems) {
        console.log(todoitems[item])
        todoitems[item].addEventListener('click', function () {
            array.splice(item, 1)
            console.log(array)
            write()
        })


    }
}


function lsread() {
    const data = JSON.parse(localStorage.getItem('todolist') || "[]")

    return data
}

function lswrite() {
    const dataString = JSON.stringify(array)
    localStorage.setItem('todolist', dataString)
}