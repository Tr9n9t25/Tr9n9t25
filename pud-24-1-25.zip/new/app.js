let search = document.getElementById('sbar');
let button = document.getElementById('btn');


async function fetchData(word) {
    const req = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${word}`);
    const res = await req.json();
    console.log(res)
    let test = res.toString();
    console.log(test)
}


button.addEventListener('click', dokoe);
function dokoe() {
    let values = search.value;

    fetchData(values);
}







