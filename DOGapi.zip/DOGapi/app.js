const section = document.getElementById('sec1')
const btn = document.getElementById('btn')
let html = ''
btn.addEventListener('click', pupper)
const selectiondog = document.getElementById('dog');
const selectioncat = document.getElementById('cat');

let lliked = document.getElementById('ll');


function printli () {
    let data = json.parse(lsread());
    let add = `<li><img src='${data}'></li>`;
    lliked.innerHTML += add;

}
printli()


async function pupper() {
    section.innerHTML = '';
    let url = await fetch(type())
    const res = await url.json();
    console.log(res)
    res.forEach(res => {
        const result = res.url;
        console.log(result)
        html = `<img id="img" src="${result}"><button onclick="toLiked()" id="liked">Like</button>`;
        section.innerHTML += html;

    })
}


function type() {
    if (selectiondog.checked === true) {
        return "https://api.thedogapi.com/v1/images/search"
    }
    else if (selectioncat.checked === true){
        return "https://api.thecatapi.com/v1/images/search"
    }
    else{
        console.log("error")
    }
}


let i = 0;
let array = [];
function toLiked() {
    let link = document.getElementById('img').src;
    let add = `<li><img src='${link}'></li>`;
    lliked.innerHTML += add;
    array.splice(i, 0, link);
    i++;
    lswrite(array)
    console.log(array)
}


function lsread() {
    const data = []
    data = JSON.parse(localStorage.getItem('img' || ""))
    return data;
    

}

function lswrite(arry) {
    const dataString = [];
    dataString = arry;
    JSON.stringify(localStorage.setItem('img', dataString))
    
}


